@echo off

echo NOTE:
echo -----
echo Temporarily enable Test Signing the driver on this PC.
echo Not needed after WHQL certification.
echo.

SET ERRORLEVEL=0
Bcdedit.exe -set TESTSIGNING ON
if errorlevel 1 goto ERROR
echo.
rem shutdown /r /t 10
rem shutdown /f /r
goto SUCCESS

:ERROR
echo.
echo.
echo Please rerun using 'Run as Administrator' option from an account with administrator privilege.
goto EXIT

:SUCCESS
echo.
echo Please restart your PC to enable test signing of the driver

:EXIT
echo.
pause